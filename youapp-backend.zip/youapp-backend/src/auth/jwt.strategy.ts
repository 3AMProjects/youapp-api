import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly configService: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(), // Extract JWT from Bearer token in Authorization header
      ignoreExpiration: false, // Ensure the JWT token is not expired
      secretOrKey: configService.get<string>('JWT_SECRET'), // Secret key for verifying JWT
    });
  }

  async validate(payload: any) {
    // This is where the payload (decoded JWT) is validated
    // The payload typically contains the user data such as email, userId, etc.
    return { userId: payload.sub, email: payload.email }; // Attach the user to the request object
  }
}
