import { Schema } from 'mongoose';

export const ProfileSchema = new Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  dateOfBirth: { type: Date, required: true },
  zodiacSign: { type: String }, // Calculated from DOB
  horoscope: { type: String }, // You can fetch this dynamically
  user: { type: Schema.Types.ObjectId, ref: 'User' },
});
