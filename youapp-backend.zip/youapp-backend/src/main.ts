import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Transport } from '@nestjs/microservices';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  // Create the Nest.js app
  const app = await NestFactory.create(AppModule);

  // Enable CORS for cross-origin requests
  app.enableCors();

  // Use global validation pipes for DTO validation
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  // Configure Swagger options
  const config = new DocumentBuilder()
    .setTitle('YouApp API')
    .setDescription('The YouApp API documentation for backend endpoints')
    .setVersion('1.0')
    .addBearerAuth() // Include JWT Bearer token authorization
    .build();

  // Create Swagger documentation
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document); // Swagger UI available at /api

  // Connect the RabbitMQ microservice
  app.connectMicroservice({
    transport: Transport.RMQ,
    options: {
      urls: ['amqp://localhost:5672'], // RabbitMQ server URL
      queue: 'messages_queue', // Queue name
      queueOptions: { durable: false }, // Queue options
    },
  });

  // Start both the HTTP server and the RabbitMQ microservice
  await app.startAllMicroservices(); // Start the microservice (RabbitMQ)
  await app.listen(3000); // Start the HTTP server on port 3000
}

bootstrap();
