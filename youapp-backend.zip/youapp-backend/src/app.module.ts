import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { ProfileModule } from './profile/profile.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }), // To manage environment variables
    MongooseModule.forRoot(
      process.env.MONGO_URI ||
        'mongodb+srv://pelealuyonathan:kI1dPZNE7oPs8RNF@cluster0.tkzt6.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',
    ), // MongoDB connection using environment variables
    AuthModule, // Authentication module
    UsersModule, // Users module
    ProfileModule, // Profile module
  ],
  controllers: [], // No need for global controllers if other modules handle routes
  providers: [], // No need for global services here if not required
})
export class AppModule {}
